//WWDC17 Playground
//By: Mohamed Salah

import UIKit
import PlaygroundSupport
import SceneKit
import AVFoundation

let PlanetsMaterialName = Constants.PlanetsMaterialName
let PlanetsName = Constants.PlanetsName
let planetsObliquity = Constants.planetsObliquity

//Set Your Height:
let viewWidth: CGFloat = 750.0
let viewHeight: CGFloat = viewWidth/1.87
let viewRect = CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight)
let view10th = viewWidth/10
let view15th = viewWidth/15
let viewHeight15th = viewHeight/15
let viewHeight7th = viewHeight/7
let view20th = viewWidth/20
let viewhalf = viewWidth/2
let view125th = viewWidth/1.25
let viewquarter = viewWidth/4

let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
let blurEffectView = UIVisualEffectView(effect: blurEffect)

let view = UIView(frame: viewRect)
let mainView = UIView(frame: viewRect)
let aboutView = UIView(frame: viewRect)
let bg = UIImageView(frame: viewRect)

let playBtn = UIButton(frame: CGRect(x: (viewhalf)-((viewquarter)/2), y: 0, width: viewquarter, height: viewHeight))
let aboutBtn = UIButton(frame: CGRect(x: (viewWidth-(view20th)), y: 10, width: view20th, height: viewHeight/20))
let logo = UIImageView(frame: CGRect(x: 10, y: (viewHeight-(view20th))-10, width: view20th, height: view20th))

let aboutBack = UIButton(frame: CGRect(x: 0, y: 10, width: view20th, height: view20th))
let aboutHeader = UILabel(frame: CGRect(x: aboutBack.frame.maxX, y: 10, width: viewWidth-(aboutBack.frame.size.width*2), height: viewHeight/6))
let aboutBody = UILabel(frame: CGRect(x: (viewhalf)-((viewWidth-(viewWidth/6))/2), y: aboutHeader.frame.maxY+10, width: viewWidth-(viewWidth/6), height: viewHeight/4))
let aboutDes = UILabel(frame: CGRect(x: logo.frame.maxX+10, y: logo.frame.origin.y, width: viewWidth-(viewWidth/13), height: view15th))

let detailsCollectionView = DetailsCollectionView(frame: CGRect(x: viewhalf-5, y: (viewHeight7th)+9, width: viewhalf, height: viewHeight-(viewHeight7th)), viewhalf: viewhalf)
let menuView = MenuCollectionView(frame: CGRect(x: -(viewWidth/2.2), y: 0, width: viewWidth/2.2, height: viewHeight))

let PlanetName = UILabel(frame: CGRect(x: view10th, y: 5, width: view125th, height: viewHeight7th))
let PlanetNote = UILabel(frame: CGRect(x: view10th, y: (viewHeight)-(viewHeight/5.8), width: view125th, height: (viewHeight/5)/1.5))
let PlaySound = UIButton(frame: CGRect(x: view10th+((view125th)/2), y: (PlanetName.frame.midY)-((viewHeight7th/2.5)/2), width: viewHeight7th/2.5, height: viewHeight7th/2.5))

let prevBtn = UIButton(frame: CGRect(x: -(view10th), y: 0, width: view10th, height: viewHeight))
let nextBtn = UIButton(frame: CGRect(x: viewWidth, y: 0, width: view10th, height: viewHeight))
let menuBtn = UIButton(frame: CGRect(x: 10, y: 10, width: view20th, height: view20th))

let sceneView = SCNView(frame: CGRect(x: view10th, y: PlanetName.frame.maxY, width: view125th, height: viewHeight-(viewHeight/5)))
let scene = SCNScene()
let cameraNode = SCNNode()

var planetIndex = 0

var detail = false
var start = true
var menu = false

let longPressGest = UILongPressGestureRecognizer()
let tapGest = UITapGestureRecognizer()
let panGest = UIPanGestureRecognizer()

var player: AVAudioPlayer?

public class Responder {
    @objc public func PlanetPrev() {
        if detail {
            ChangeToDefault()
            detail = false
            
            longPressGest.isEnabled = true
            tapGest.isEnabled = false
            
        }else {
            if cameraNode.position.x != 0 {
                planetIndex -= 1
                
                let moveCameraAc = SCNAction.move(by: SCNVector3Make(-30, 0, 0), duration: 1)
                moveCameraAc.timingMode = .easeInEaseOut
                cameraNode.runAction(moveCameraAc)
                
                PlanetName.ChangePlanet(Text: PlanetsName[planetIndex])
                
                detailsCollectionView.planetIndex = planetIndex
                detailsCollectionView.reloadData()
                
                if planetIndex == 0 {
                    prevBtn.isEnabled = false
                }else if planetIndex == 6 {
                    nextBtn.isEnabled = true
                }
                
                prevBtn.bounce()
                
                UIView.animate(
                    withDuration: 1,
                    delay: 0.0,
                    usingSpringWithDamping: 1.1,
                    initialSpringVelocity: 1.5,
                    options: UIViewAnimationOptions.curveEaseInOut,
                    animations: ({
                        PlaySound.frame.origin.x = (view10th+((view125th)/2))+(PlanetName.getTextSize().width/1.7)
                    }), completion: nil)
            }
        }
    }
    
    @objc func PlanetNext() {
        if cameraNode.position.x < Float((view125th)*8) {
            planetIndex += 1
            
            let moveCameraAc = SCNAction.move(by: SCNVector3Make(30, 0, 0), duration: 1)
            moveCameraAc.timingMode = .easeInEaseOut
            cameraNode.runAction(moveCameraAc)
            
            PlanetName.ChangePlanet(Text: PlanetsName[planetIndex])
            
            detailsCollectionView.planetIndex = planetIndex
            detailsCollectionView.reloadData()
            
            if planetIndex == 7 {
                nextBtn.isEnabled = false
            }else if planetIndex == 1 {
                prevBtn.isEnabled = true
            }
            
            nextBtn.bounce()
            
            UIView.animate(
                withDuration: 1,
                delay: 0.0,
                usingSpringWithDamping: 1.1,
                initialSpringVelocity: 1.5,
                options: UIViewAnimationOptions.curveEaseInOut,
                animations: ({
                    PlaySound.frame.origin.x = (view10th+((view125th)/2))+(PlanetName.getTextSize().width/1.7)
                }), completion: nil)
            
        }
    }

    @objc func AboutBtn() {
        UIView.animate(
            withDuration: 1,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                if start {
                    aboutView.alpha = 1
                    playBtn.alpha = 0
                    aboutBtn.alpha = 0
                }else {
                    aboutView.alpha = 1
                    blurEffectView.alpha = 1
                    logo.alpha = 1
                    aboutBtn.alpha = 0
                    panGest.isEnabled = false
                }
            }), completion: nil)
        
    }
    
    @objc func AboutBackBtn() {
        UIView.animate(
            withDuration: 1,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                if start {
                    aboutView.alpha = 0
                    playBtn.alpha = 1
                    aboutBtn.alpha = 1
                }else {
                    aboutView.alpha = 0
                    blurEffectView.alpha = 0
                    logo.alpha = 0.5
                    aboutBtn.alpha = 1
                    if !detail {
                        panGest.isEnabled = true
                    }
                }
            }), completion: nil)
        
    }
    
    @objc func Play() {
        start = false
        panGest.isEnabled = true
        
        UIView.animate(
            withDuration: 1,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                
                playBtn.frame.origin.y -= viewHeight
                logo.alpha = 0.5
                
                prevBtn.frame.origin.x = 0
                nextBtn.frame.origin.x = sceneView.frame.maxX
                blurEffectView.alpha = 0
                
            }), completion: {finished in
                playBtn.removeFromSuperview()
        })
    }
    
    @objc func longPressDetails(gesture: UILongPressGestureRecognizer) {
        longPressGest.isEnabled = false
        tapGest.isEnabled = true
        detail = true
        ChangeToDetail()
    }
    
    @objc func playPlanetName() {
        let url = Bundle.main.url(forResource: PlanetsName[planetIndex], withExtension: "mp3")!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            guard let player = player else { return }
            
            player.prepareToPlay()
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    @objc func ShowDismissMenu() {
        
        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                
                if !menu {
                    menu = true
                    menuView.frame.origin.x = 0
                    mainView.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
                    mainView.frame.origin.x = menuView.frame.maxX
                }else {
                    menu = false
                    mainView.transform = CGAffineTransform(scaleX: 1, y: 1)
                    mainView.frame.origin.x = 0
                    
                    menuView.frame.origin.x = -(menuView.frame.size.width)
                }
                
            }), completion: nil)
        
        menuBtn.bounce()
    }
    
    var progress:CGFloat = 0
    var progressLeft:CGFloat = 0
    
    @objc func ShowHideMenuGest(gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: view)
        
        switch (gesture.state) {
            
        case UIGestureRecognizerState.began:
            //begin
            break
            
        case UIGestureRecognizerState.changed:
            var percent:CGFloat = 0
            var show = true
            
            if translation.x > 0 {
                if menuView.frame.origin.x == 0 {
                    show = false
                }
                progress += translation.x
                percent = progress/(menuView.frame.size.width)
            }else {
                if menuView.frame.origin.x == -(menuView.frame.size.width) {
                    show = false
                }
                progressLeft += translation.x
                percent = (progressLeft/(menuView.frame.size.width))*(-1)
            }
            
            if percent <= 1 {
                if show {
                    menuView.frame.origin.x += translation.x
                    if translation.x > 0 {
                        mainView.transform = CGAffineTransform(scaleX: 1-(percent*0.1), y: 1-(percent*0.1))
                    }else {
                        mainView.transform = CGAffineTransform(scaleX: 1+(percent*0.1), y: 1+(percent*0.1))
                    }
                }
            }else {
                menuView.frame.origin.x = 0
            }
            
            mainView.frame.origin.x = menuView.frame.maxX
            
            gesture.setTranslation(CGPoint.zero, in: view)
            break
            
        default:
            
            UIView.animate(
                withDuration: 0.5,
                delay: 0.0,
                usingSpringWithDamping: 1.1,
                initialSpringVelocity: 1.5,
                options: UIViewAnimationOptions.curveEaseInOut,
                animations: ({
                    
                    if menuView.frame.origin.x > (-menuView.frame.size.width/2.5) {
                        menuView.frame.origin.x = 0
                        mainView.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
                        menu = true
                    }else {
                        menuView.frame.origin.x = -menuView.frame.size.width
                        mainView.transform = CGAffineTransform(scaleX: 1, y: 1)
                        menu = false
                    }
                    
                    mainView.frame.origin.x = menuView.frame.maxX
                    
                }), completion: nil)
            
            progress = 0
            progressLeft = 0
            break
        }
        
    }
    
    @objc func GoToPlanet() {
        planetIndex = menuView.tag
        
        let moveCameraAc = SCNAction.move(to: SCNVector3Make(Float(planetIndex*30), 0, 14), duration: 1)
        moveCameraAc.timingMode = .easeInEaseOut
        cameraNode.runAction(moveCameraAc)
        
        PlanetName.ChangePlanet(Text: PlanetsName[planetIndex])
        
        detailsCollectionView.planetIndex = planetIndex
        detailsCollectionView.reloadData()
        
        if planetIndex == 7 {
            nextBtn.isEnabled = false
        }else if planetIndex == 1 {
            prevBtn.isEnabled = true
        }else if planetIndex == 0 {
            prevBtn.isEnabled = false
        }else if planetIndex == 6 {
            nextBtn.isEnabled = true
        }else {
            prevBtn.isEnabled = true
            nextBtn.isEnabled = true
        }
        
        menu = false
        
        UIView.animate(
            withDuration: 1,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                PlaySound.frame.origin.x = (view10th+((view125th)/2))+(PlanetName.getTextSize().width/1.7)
                mainView.transform = CGAffineTransform(scaleX: 1, y: 1)
                mainView.frame.origin.x = 0
                
                menuView.frame.origin.x = -(menuView.frame.size.width)
                
            }), completion: nil)
    }
}

func ChangeToDetail() {
    prevBtn.isEnabled = true
    panGest.isEnabled = false
    UIView.animate(
        withDuration: 0.5,
        delay: 0.0,
        usingSpringWithDamping: 1.1,
        initialSpringVelocity: 1.5,
        options: UIViewAnimationOptions.curveEaseInOut,
        animations: ({
            
            detailsCollectionView.transform = CGAffineTransform(scaleX: 1, y: 1)
            
            menuBtn.frame.origin.y -= menuBtn.frame.size.height+10
            prevBtn.frame = CGRect(x: 0, y: 10, width: view20th, height: view20th)
            nextBtn.frame.origin.x += (nextBtn.frame.size.width)
            
            PlanetNote.frame.origin.y += (PlanetNote.frame.size.height)
            sceneView.frame = CGRect(x: view20th-10, y: 10, width: viewhalf, height: viewHeight)
            
        }), completion: nil)
}

func ChangeToDefault() {
    if planetIndex == 0 {
        prevBtn.isEnabled = false
    }
    panGest.isEnabled = true
    
    UIView.animate(
        withDuration: 0.5,
        delay: 0.0,
        usingSpringWithDamping: 1.1,
        initialSpringVelocity: 1.5,
        options: UIViewAnimationOptions.curveEaseInOut,
        animations: ({
            
            detailsCollectionView.transform = CGAffineTransform(scaleX: 0.0001, y: 0.0001)
            
            menuBtn.frame.origin.y = 10
            prevBtn.frame = CGRect(x: 0, y: 0, width: view10th, height: viewHeight)
            nextBtn.frame.origin.x -= (nextBtn.frame.size.width)*2
            
            PlanetNote.frame.origin.y -= (PlanetNote.frame.size.height)*2
            
            sceneView.frame = CGRect(x: view10th, y: PlanetName.frame.maxY, width: view125th, height: viewHeight-(viewHeight/5))
            
        }), completion: {finished in
            detailsCollectionView.transform = CGAffineTransform(scaleX: 0, y: 0)
    })
}

func degToRadian(deg: Float)->Float {
    return Float(deg / 180) * Float.pi
}

let receiver = Responder()

NotificationCenter.default.addObserver(receiver, selector: #selector(receiver.GoToPlanet), name: NSNotification.Name(rawValue: "MenuItemSelected"), object: nil)

aboutView.backgroundColor = .clear
aboutView.alpha = 0
menuView.bounds = menuView.frame.insetBy(dx: 0, dy: 5.0)
mainView.backgroundColor = UIColor(red: 0, green: 0, blue: 38)

blurEffectView.frame = view.bounds
blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]

detailsCollectionView.transform = CGAffineTransform(scaleX: 0, y: 0)

prevBtn.imageView?.contentMode = .scaleAspectFit
nextBtn.imageView?.contentMode = .scaleAspectFit
playBtn.imageView?.contentMode = .scaleAspectFit
aboutBack.imageView?.contentMode = .scaleAspectFit
aboutBtn.imageView?.contentMode = .scaleAspectFit
PlaySound.imageView?.contentMode = .scaleAspectFit
menuBtn.imageView?.contentMode = .scaleAspectFit

prevBtn.isEnabled = false

logo.contentMode = .scaleAspectFit

prevBtn.setImage(UIImage(named: "per.png"), for: .normal)
nextBtn.setImage(UIImage(named: "next.png"), for: .normal)
playBtn.setImage(UIImage(named: "playBtn.png"), for: .normal)
aboutBtn.setImage(UIImage(named: "about.png"), for: .normal)
aboutBack.setImage(UIImage(named: "per.png"), for: .normal)
PlaySound.setImage(UIImage(named: "speaker.png"), for: .normal)
menuBtn.setImage(UIImage(named: "menu.png"), for: .normal)

bg.image = UIImage(named: "SpaceBG.jpg")
logo.image = UIImage(named: "logo.png")

PlanetName.text = PlanetsName[0]
PlanetNote.text = "Long Press The Planet To Show Details"

aboutHeader.text = "Solar System WWDC17 App"
aboutBody.text = "This app shows you some information about solar system planets using 3d models."
aboutDes.text = "Designed And Developed By: Mohamed Salah"

PlanetName.Setup(fontSize: view20th)
PlanetNote.Setup(fontSize: viewWidth/30)
aboutHeader.Setup(fontSize: view20th)
aboutBody.Setup(fontSize: viewWidth/23)
aboutDes.Setup(fontSize: viewWidth/30)

PlaySound.frame.origin.x += PlanetName.getTextSize().width/1.7

PlanetNote.textColor = .lightText
aboutDes.textAlignment = .left
aboutBody.numberOfLines = 6

nextBtn.addTarget(receiver, action: #selector(Responder.PlanetNext), for: .touchUpInside)
prevBtn.addTarget(receiver, action: #selector(Responder.PlanetPrev), for: .touchUpInside)
playBtn.addTarget(receiver, action: #selector(Responder.Play), for: .touchUpInside)
aboutBtn.addTarget(receiver, action: #selector(Responder.AboutBtn), for: .touchUpInside)
aboutBack.addTarget(receiver, action: #selector(Responder.AboutBackBtn), for: .touchUpInside)
PlaySound.addTarget(receiver, action: #selector(Responder.playPlanetName), for: .touchUpInside)
menuBtn.addTarget(receiver, action: #selector(Responder.ShowDismissMenu), for: .touchUpInside)

longPressGest.addTarget(receiver, action: #selector(Responder.longPressDetails(gesture:)))
tapGest.addTarget(receiver, action: #selector(Responder.PlanetPrev))
panGest.addTarget(receiver, action: #selector(Responder.ShowHideMenuGest(gesture:)))

tapGest.isEnabled = false
panGest.isEnabled = false

sceneView.backgroundColor = .clear
sceneView.autoenablesDefaultLighting = true
sceneView.addGestureRecognizer(longPressGest)
sceneView.addGestureRecognizer(tapGest)

view.addGestureRecognizer(panGest)

cameraNode.camera = SCNCamera()
cameraNode.position = SCNVector3Make(0, 0, 14)
scene.rootNode.addChildNode(cameraNode)

for i in 0 ..< 8 {
    let PlanetGeometry = SCNSphere(radius: 5)
    let PlanetNode = SCNNode(geometry: PlanetGeometry)
    
    PlanetNode.position = SCNVector3Make(Float((30)*CGFloat(i)), 0, 0)
    
    let material = SCNMaterial()
    material.diffuse.contents = UIImage(named: PlanetsMaterialName[i])
    PlanetGeometry.materials = [material]
    PlanetNode.eulerAngles = SCNVector3Make(0, 0, degToRadian(deg: Float(planetsObliquity[i])))
    scene.rootNode.addChildNode(PlanetNode)
    PlanetNode.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: 50)))
}

sceneView.scene = scene

mainView.addSubview(bg)
mainView.addSubview(prevBtn)
mainView.addSubview(sceneView)
mainView.addSubview(PlanetName)
mainView.addSubview(PlaySound)
mainView.addSubview(PlanetNote)
mainView.addSubview(nextBtn)
mainView.addSubview(detailsCollectionView)
mainView.addSubview(menuBtn)
mainView.addSubview(blurEffectView)

mainView.addSubview(playBtn)
mainView.addSubview(aboutBtn)
mainView.addSubview(logo)

view.addSubview(mainView)
view.addSubview(menuView)
view.addSubview(aboutView)

aboutView.addSubview(aboutBack)
aboutView.addSubview(aboutDes)
aboutView.addSubview(aboutHeader)
aboutView.addSubview(aboutBody)

PlaygroundPage.current.liveView = view

//Finished in 28/3/2017 10:56 AM
