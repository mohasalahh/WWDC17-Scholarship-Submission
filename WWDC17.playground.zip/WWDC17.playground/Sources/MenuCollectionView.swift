import UIKit
import SceneKit

public class MenuCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    
    public init(frame: CGRect) {
        let layout = UICollectionViewFlowLayout()
        super.init(frame: frame, collectionViewLayout: layout)
        
        self.dataSource = self
        self.delegate = self
        self.backgroundColor = UIColor(red: 0, green: 0, blue: 38)
        
        self.register(MenuCollectionViewCell.self, forCellWithReuseIdentifier: "MenuCell")
    }
    
    required public init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    public func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuCell", for: indexPath) as! MenuCollectionViewCell
        
        cell.PlanetName.text = Constants.PlanetsName[indexPath.row]
        cell.PlanetImage.image = UIImage(named: Constants.PlanetsMaterialName[indexPath.row])?.cropToSquare().cropToCircle()
        
        return cell
    }

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.frame.size.width/2)-10, height: (((self.frame.size.width/2)-10)*1.4)+25)
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! MenuCollectionViewCell
        
        self.tag = indexPath.row
        
        UIView.animate(
            withDuration: 0.3,
            delay: 0.0,
            usingSpringWithDamping: 1.1,
            initialSpringVelocity: 1.5,
            options: UIViewAnimationOptions.curveEaseInOut,
            animations: ({
                
                cell.PlanetImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                
            }), completion: {finished in
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "MenuItemSelected"), object: nil)
                
                UIView.animate(
                    withDuration: 0.3,
                    delay: 0.0,
                    usingSpringWithDamping: 1.1,
                    initialSpringVelocity: 1.5,
                    options: UIViewAnimationOptions.curveEaseInOut,
                    animations: ({
                        
                        cell.PlanetImage.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                        
                    }), completion: nil)
        })
        
        
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 5, 0, 5)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}

