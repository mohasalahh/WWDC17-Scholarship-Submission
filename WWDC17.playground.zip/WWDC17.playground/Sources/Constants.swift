import Foundation

public struct Constants {
    public static let PlanetsMaterialName = ["mer.jpg", "v.jpg", "e.jpg", "m.jpg", "j.jpg", "s.jpg", "u.jpg", "n.jpg"]
    public static let PlanetsName = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    public static let planetsObliquity = [-0.1, -177, -23, -25, -3, -27, -98, -30]
    public static let planetsInfoImg = ["diameter.png", "orbit.png", "rotation.png", "distance.png", "temp.png", "moons.png"]
    public static let planetsInfoTitle = ["Diameter", "Orbit Duration", "Rotation Duration", "Distance From ☀️", "Max Temp", "Number Of Moons"]
    public static let planetsInfoMeasure = ["KM", "Earth Days", "Earth Days", "AU", "°Celsius", ""]
    public static let planetsInfo = [[4878, 88, 58.6, 0.39, 427, 0], [12104, 225, 241, 0.73, 462, 0], [12760, 365.24, 23.53, 1, 58, 1], [6787, 1.9, 24.5, 1.38, 20, 2], [139822, 11.9, 9.8, 5.2, -148, 67], [120500, 29.5, 10.5, 9.58, -178, 62], [51120, 84, 18, 19.22, -216, 27], [49530, 165, 19, 30.1, -214, 14]]
}
public enum Direction {
    case Up
    case Down
    case Left
    case Right
}
