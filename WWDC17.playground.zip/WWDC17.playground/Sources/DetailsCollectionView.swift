import UIKit

public class DetailsCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    public var planetIndex = 0
    
    public var viewhalf: CGFloat!
    
    public init(frame: CGRect, viewhalf: CGFloat) {
        let layout = UICollectionViewFlowLayout()
        super.init(frame: frame, collectionViewLayout: layout)
        
        self.viewhalf = viewhalf
        self.dataSource = self
        self.delegate = self
        self.backgroundColor = .clear
        
        self.register(DetailsCollectionViewCell.self, forCellWithReuseIdentifier: "DetailCell")
    }
    
    required public init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    public func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailCell", for: indexPath) as! DetailsCollectionViewCell
        
        if planetIndex >= 3 && indexPath.row == 1 {
            cell.infoMeasure.text = "Earth Years"
        }else {
            cell.infoMeasure.text = Constants.planetsInfoMeasure[indexPath.row]
        }
        
        if indexPath.row == 0 {
            cell.infoContent.text = Int(Constants.planetsInfo[planetIndex][indexPath.row] as NSNumber).formatInt()
        }else {
            cell.infoContent.text = String(describing: Constants.planetsInfo[planetIndex][indexPath.row])
        }
        
        cell.infoTitle.text = Constants.planetsInfoTitle[indexPath.row]
        
        cell.infoIcon.image = UIImage(named: Constants.planetsInfoImg[indexPath.row])
    
        return cell
    }

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (viewhalf/2)-10, height: ((((viewhalf*2)/1.87)-((viewhalf*2)/1.87)/7)/3)-10)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 5, 0, 5)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}
