import UIKit

public class DetailsCollectionViewCell: UICollectionViewCell {
    
    var infoIcon:UIImageView!
    
    var infoTitle:UILabel!
    var infoContent:UILabel!
    var infoMeasure:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let infoViewWidth = self.frame.size.width
        let infoViewHeight = self.frame.size.height
        let viewWidth = (infoViewWidth*4)+10
        
        self.backgroundColor = UIColor(red: 32, green: 41.0, blue: 68.0)
        self.clipsToBounds = true
        self.layer.cornerRadius = viewWidth/75
        
        infoIcon = UIImageView(frame: CGRect(x: (infoViewWidth/2)-((infoViewWidth/1.2)/2), y: (infoViewHeight/2)-((infoViewHeight/1.2)/2), width: infoViewWidth/1.2, height: infoViewHeight/1.2))
        
        infoTitle = UILabel(frame: CGRect(x: (viewWidth/187.5)+5, y: viewWidth/187.5, width: infoViewWidth, height: (infoViewHeight/3)-(viewWidth/187.5)))
        infoContent = UILabel(frame: CGRect(x: 0, y: infoTitle.frame.maxY+(viewWidth/187.5), width: infoViewWidth, height: infoTitle.frame.size.height))
        infoMeasure = UILabel(frame: CGRect(x: viewWidth/(-50), y: infoContent.frame.maxY+(viewWidth/187.5), width: infoViewWidth, height: infoTitle.frame.size.height))
        
        infoIcon.alpha = 0.05
        infoIcon.contentMode = .scaleAspectFit
        
        infoTitle.Setup(fontSize: viewWidth/32)
        infoContent.Setup(fontSize: viewWidth/25)
        infoMeasure.Setup(fontSize: viewWidth/35)
        
        infoTitle.textAlignment = .left
        infoMeasure.textAlignment = .right
        
        self.addSubview(infoIcon)
        self.addSubview(infoTitle)
        self.addSubview(infoContent)
        self.addSubview(infoMeasure)
    }
    
    required public init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
}
